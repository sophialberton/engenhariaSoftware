## Exercício Jogo X O
- Data de conclusão 13 de agosto de 2025 às 21:00
### Instruções
Criar o jogo X - O 
- Gerar um arquivo html
- Gerar um arquivo CSS
- Gerar um arquivo JS

Criar o grid e a lógica de funcionamento do jogo.

Salvar o projeto como um zip e anexar nesta atividade