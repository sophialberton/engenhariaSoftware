// src/library.js

const livros = [];

function adicionarLivro(livro) {
  // TODO: implementar função
}

function buscarLivroPorTitulo(titulo) {
  // TODO: implementar função
}

function listarLivros() {
  // TODO: implementar função
}

function removerLivro(titulo) {
  // TODO: implementar função
}

function resetarBiblioteca() {
  livros.length = 0; // Limpa a lista
}

module.exports = {
  adicionarLivro,
  buscarLivroPorTitulo,
  listarLivros,
  removerLivro,
  resetarBiblioteca
};
