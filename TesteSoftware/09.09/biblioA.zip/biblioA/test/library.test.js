// test/library.test.js

const test = require('node:test');
const assert = require('assert');
const biblioteca = require('../src/library.js');

test('Adicionar e listar livros', () => {
  // TODO: implementar teste
});

test('Buscar livro por título', () => {
  // TODO: implementar teste
});

test('Remover livro', () => {
  // TODO: implementar teste
});

test('Não permitir adicionar livro duplicado', () => {
  // TODO: implementar teste
});
