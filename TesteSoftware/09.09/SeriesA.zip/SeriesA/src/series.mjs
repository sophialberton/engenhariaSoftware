// series.mjs

// Lista interna que armazena as séries
const seriesList = [];

/**
 * Adiciona uma nova série ao sistema.
 * @param {Object} series - Objeto com os dados da série.
 * Deve conter: name, releaseYear, episodes, episodeDuration, timesWatched
 */
export function addSeries(series) {
  // TODO: implementar
}

/**
 * Retorna todas as séries cadastradas.
 * @returns {Array} lista de séries
 */
export function getAllSeries() {
  // TODO: implementar
}

/**
 * Filtra séries pelo ano de lançamento.
 * @param {number} year - Ano desejado
 * @returns {Array} séries lançadas naquele ano
 */
export function filterByYear(year) {
  // TODO: implementar
}

/**
 * Filtra séries que têm pelo menos minEpisodes episódios.
 * @param {number} minEpisodes - número mínimo de episódios
 * @returns {Array} séries filtradas
 */
export function filterByMinEpisodes(minEpisodes) {
  // TODO: implementar
}

/**
 * Filtra séries cuja duração do episódio está dentro do intervalo [minMinutes, maxMinutes].
 * @param {number} minMinutes - duração mínima
 * @param {number} maxMinutes - duração máxima
 * @returns {Array} séries filtradas
 */
export function filterByEpisodeDurationRange(minMinutes, maxMinutes) {
  // TODO: implementar
}

/**
 * Filtra séries que foram assistidas pelo menos minTimes vezes.
 * @param {number} minTimes - número mínimo de vezes assistidas
 * @returns {Array} séries filtradas
 */
export function filterByTimesWatched(minTimes) {
  // TODO: implementar
}

/**
 * Função auxiliar para limpar a lista (útil para testes).
 */
export function clearSeries() {
  seriesList.length = 0;
}
