// series.test.mjs

import test from 'node:test';
import assert from 'assert';
import {
  addSeries,
  getAllSeries,
  filterByYear,
  filterByMinEpisodes,
  filterByEpisodeDurationRange,
  filterByTimesWatched,
  clearSeries
} from './series.mjs';

test('setup: limpar lista antes de cada teste', () => {
  clearSeries();
});

// Testes vazios a preencher:

test('addSeries deve adicionar uma série', () => {
  // TODO: implementar teste
});

test('getAllSeries deve retornar todas as séries cadastradas', () => {
  // TODO: implementar teste
});

test('filterByYear deve retornar séries do ano especificado', () => {
  // TODO: implementar teste
});

test('filterByMinEpisodes deve retornar séries com episódios mínimos', () => {
  // TODO: implementar teste
});

test('filterByEpisodeDurationRange deve filtrar por duração dos episódios', () => {
  // TODO: implementar teste
});

test('filterByTimesWatched deve retornar séries com mínimo de vezes assistidas', () => {
  // TODO: implementar teste
});
